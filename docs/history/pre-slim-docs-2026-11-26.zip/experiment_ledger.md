# 实验台账（Experiment Ledger）

本台账逐个梳理 `src/backtest/` 下的回测实验脚本与配套报告，记录每个实验的**目的 → 核心结论 → 是否进生产 → 对应生产配置项**，服务于"证明策略有效性"的可追溯目标。当某个实验改进被采纳进生产时，应能从这里反查到它落在 `settings.yaml` 的哪个键。

## 阅读须知（口径与方法论前提）

- **唯一可比的主引擎**是 `src/backtest/portfolio_backtest.py` 的 `PortfolioBacktest`：真实账户净值口径（cash + 持仓市值）、T+1 撮合无未来函数、复用生产 `generate_advice`。本台账除特别标注外，所有实验都跑在这套引擎上，数字互相可比。
- **`odds_gate_backtest.py` 是独立的简化口径**（多 ETF 百分比盈亏累加、无现金池、无止损风控），其数字**不能与主引擎或其它实验并列**，仅供"赔率门控 vs 无门控"的自身相对增量对比。详见 `docs/tesy_modify_advice.md`。
- **报告脚本（`*_report.py`）不在源码里写死结果数字**：年化/回撤/胜率等由 `run_ablation_backtest` 运行时实时计算。源码内固化的是实验的**判定逻辑/阈值**（如 `_window_decision`、`_row_judgement`、`_version_judgement`）。因此本台账的"核心结论"来自：① 已落盘的 `.md` 报告里的数字结论；② 脚本判定逻辑与 docstring 文案；③ 生产侧 `settings.yaml` 与 README 的最终状态反推采纳与否。
- **采纳与否的最硬证据是 `settings.yaml`**：若某规则在生产配置里没有对应键，即可判定该实验线"未进生产"。
- 所有实验脚本已统一收敛到 `src/backtest/`，原 `src/ds_backtest/` 目录已合并删除。

---

## 一、台账总表

| 实验脚本 / 报告 | 主题 | 验证对象 | 核心结论 | 是否进生产 | 生产配置项 |
|---|---|---|---|---|---|
| `ablation_report.py` | 基础设施 | 多套消融矩阵的统一 runner/formatter | 工具本身无结论；承载已采纳的 70/15/15 与分段止损实验 | 工具 | — |
| `ablation_config.py` | 基础设施 | 实验定义与规则常量库（被各 runner 调用） | 规则常量集中地 | 工具 | — |
| `run_reentry_ablation.py` + `reentry_ablation_report.md` | 再入场 | 止损后 7 种再入场过滤规则 | **否决**：长短窗口结论相反，过拟合，无规则跨窗口稳健达标 | ❌ 否 | 无 reentry 键 |
| `simple_reentry_ablation.py` + `simple_reentry_report.md` | 再入场 | 4 种朴素 reentry 思路（3T冷却/止损价约束/跳过首BUY） | **否决**：3T冷却无效、跳过首BUY长短窗口反向、止损价约束仅长窗口微增 | ❌ 否 | 无 reentry 键 |
| `attribution_report.py` | 归因工具 | v2.2 市场热度门控拦截的有效性（逐笔避损 vs 误杀） | 归因报表工具，无硬编码结论；分析对象（市场门控）已在生产 | 工具 | 市场 regime 门控（现行） |
| `misjudge_report.py` | 诊断工具 | 高亏损（≤-10%）平仓单四维归因（策略/执行/风控/未知） | 诊断报表工具，指导后续规则改进方向 | 工具 | — |
| `high_vol_mixed_strategy_report.py` | 高波动 | 全池验证 high_vol 专用底层信号（`high_vol_balanced`） | **采纳为锚点**：换信号本身有效，作为后续高波实验的基础 | ✅ 是 | `volatility_signal_profiles.high_vol` |
| `high_vol_frequency_control_report.py` | 高波动 | 高波 ETF 交易频率控制（止损-12%/确认日/加仓间隔/最大持仓等） | **否决**：未采纳为独立频控模块，高波止损也未统一改 -12% | ❌ 否 | 无频控键 |
| `high_vol_quality_control_report.py` | 高波动 | 高波建仓/加仓质量控制（质量分/动量/Top2/预算分层） | **采纳分层**：`quality budget_tier` 脱颖而出 | ✅ 是 | `entry_budget_overrides.high_vol` |
| `high_vol_quality_tier_robustness_report.py` | 高波动 | 对质量分层做参数/滚动窗口/分市场/单ETF 四重稳健性验证 | 确认 65/55 阈值与 1.00/0.80/0.60 乘数稳健，参数落地生产 | ✅ 是（确认环节） | `entry_budget_overrides.high_vol` 参数 |
| `high_vol_quality_capital_attribution_report.py` | 高波动 | 质量分层的资金再分配归因（解释收益/拖累来自哪个 ETF） | 解释性归因工具，不产生新配置 | 工具 | — |
| `volatility_strategy_report.py` | 波动率配置 | 高/低波差异化执行阈值（建仓/加仓 score 门槛） | 部分理念被采纳（high_vol 分层预算落地），完整阈值方案未原样采纳 | 部分 | `entry_add_budget` / `entry_budget_overrides.high_vol` |
| `volatility_profile_strategy_report.py` | 波动率配置 | 高/低波各自专用底层信号 | high_vol 信号采纳；**low_vol 信号否决**（沿用 v2.3 信号） | 部分 | `volatility_signal_profiles.high_vol`（仅高波） |
| `volatility_focus_anchor_report.py` | 波动率配置 | 策略重心锚点（低波核心+高波卫星 vs 全池） | 探索/诊断；当前仍是全池质量分层口径，未改卫星制 | ❌ 否 | — |
| `portfolio_risk_control_report.py` | 组合风控 | 组合层风控（持仓数/高波数/暴露上限的拦截与缩放） | 候选筛选；当前生产无组合级风控键，未采纳 | ❌ 否 | 无组合风控键 |
| `relative_strength_report.py` | 相对强弱 | 横截面相对强弱（RS）选股因子（收益排序/超额/前40%过滤） | **否决**：README 明确"相对强弱实验不采纳" | ❌ 否 | 无 RS 键 |
| `relative_strength.py` | 相对强弱 | RS 实验的计算辅助库（被上条引用） | 随 RS 实验一同未进生产 | ❌ 否 | — |
| `experimental_signals.py` | 基础设施 | 回测专用实验性底层信号生成器 | `high_vol_balanced` 采纳；`low_vol_stable` 未采纳 | 部分 | `volatility_signal_profiles.high_vol` |

---

## 二、已进生产的关键配置项（采纳结果速查）

以下配置项均在 `settings.yaml` 的 `strategy.params` 与 `risk_control` 段（参见 `settings.yaml.example` 第 319–348 行）。它们是上述实验线被采纳的最终落地：

| 配置键 | 值 | 来源实验 |
|---|---|---|
| `strategy.params.entry_add_budget` | 70/15/15 阶梯（建仓 0.70 + 两档 0.15 加仓，min_score 60/70，require_profit） | `ablation_report.py` 的 `entry-add-budget` 矩阵 |
| `strategy.params.volatility_signal_profiles.high_vol` | `enabled: true, kind: "high_vol_balanced"` | `high_vol_mixed_strategy_report.py` / `volatility_profile_strategy_report.py` / `experimental_signals.py` |
| `strategy.params.entry_budget_overrides.high_vol` | `kind: "quality_tier"`，`strong_score 65 → 1.00`、`medium_score 55 → 0.80`、`weak → 0.60` | `high_vol_quality_control_report.py`（选出）+ `high_vol_quality_tier_robustness_report.py`（确认参数） |
| `risk_control.rules.max_holding_days` | `days: 90` | v2.4 基线（90 日最大持有） |
| `risk_control.rules.profile_stop_loss` | `default_profile: "fixed_8"`，各 ETF 另配 `stop_loss_profile`（`atr_2_5` / `fixed_8` / `none`） | `ablation_report.py` 的 `stop-loss-rules` / `stop-loss-by-segment` 矩阵（分市场/分波动止损） |

---

## 三、明确被否决的实验线（不可追溯到任何生产键）

记录否决线同样重要——它们是"试过且证伪"的证据，避免重复探索：

- **止损后再入场过滤（reentry）整条线**：`run_reentry_ablation.py`（7 规则）与 `simple_reentry_ablation.py`（4 思路）均未通过跨窗口稳健性检验。`settings.yaml` 的 `risk_control.rules` 只有 `max_holding_days` 与 `profile_stop_loss`，**无任何 reentry/cooldown 键**。其中"趋势修复"被单拎出做后续分组验证（`trend-reentry-segments` 矩阵，候选名 `candidate_v2_5_trend_reentry`），同样未落地。
- **高波动频率控制**：`high_vol_frequency_control_report.py` 测的止损 -12%、BUY/SELL 确认日、加仓间隔、最大持仓数等频控规则均未采纳；生产高波止损沿用各 ETF `stop_loss_profile`（多为 `atr_2_5`），未统一改 -12%。
- **low_vol 专用底层信号**：`volatility_profile_strategy_report.py` / `experimental_signals.py` 的 `low_vol_stable` profile 未进生产；low_vol 继续沿用 v2.3 信号（`volatility_signal_profiles` 下只有 `high_vol` 键）。
- **组合层风控**：`portfolio_risk_control_report.py` 的持仓数/暴露上限类组合级风控候选未采纳，生产保留全池质量分层锚点观察。
- **相对强弱（RS）选股因子**：`relative_strength_report.py` + `relative_strength.py` 不采纳，`settings.yaml` 无任何 RS 键（README 已明确记载）。
- **重心锚点改卫星制**：`volatility_focus_anchor_report.py` 探索的"低波核心 + 高波卫星"未替换当前全池口径。

---

## 四、维护约定

- 新增实验脚本或报告时，应在本台账"总表"补一行，并在采纳后回填"生产配置项"列。
- 实验被采纳进生产时，务必在第二节登记对应 `settings.yaml` 键；被否决时在第三节记录，写清否决理由（尤其是过拟合/跨窗口不稳健这类需要避免重复踩坑的结论）。
- 报告数字会随回测窗口和数据更新而变化，本台账只记"结论与是否进生产"，具体数字以最新落盘的 `.md` 报告或重跑结果为准。
