# Architecture

## 项目目标

ETF 右侧交易助手用于跟踪一组 ETF 的日线趋势，生成技术信号、风控信号和操作建议。系统定位是个人交易辅助工具：

- 不做价格预测，只做趋势确认后的右侧跟随。
- 用多指标评分降低单一均线策略的误判。
- 用高溢价硬门控避免 ETF 溢价交易风险；长期赔率状态不再直接硬拦截趋势信号。
- 用 gate-lite 市场门控只拦截极端下行状态，避免全市场热度规则误杀趋势延续。
- 用可复盘的数据库记录支撑 Dashboard、盈亏分析和回测比较。

## 总体架构

```text
main.py / ablation.py / init_db.py
  -> runner / scheduler / dashboard
    -> service
      -> fetcher / indicators / strategy / risk / advisor
        -> database repository
          -> SQLAlchemy schema
            -> PostgreSQL
```

分层职责：

| 层 | 路径 | 职责 |
|---|---|---|
| CLI | `main.py` | 生产命令入口：初始化、每日运行、调度、仪表盘、信号重建和常规回测 |
| 实验 | `ablation.py` | 消融实验入口：候选矩阵、参数消融和再入场等本地实验 |
| 初始化 | `init_db.py` | 建表、历史回填、指标回填、信号生成 |
| 编排 | `src/runner/` | 每日 STEP 1-5 主流程 |
| 采集 | `src/fetcher/` | BaoStock、AKShare/EastMoney、Tushare 数据源封装 |
| 指标 | `src/indicators/` | MA、MACD、Bollinger、RSI、Volume、ADX、ATR、LongTermOdds |
| 策略 | `src/strategy/` | 技术评分并映射 `BUY / SELL / HOLD` |
| 风控 | `src/risk/` | 止损、回撤止盈规则链 |
| 建议 | `src/advisor/` | 持仓、信号、赔率、市场热度和风控合成为操作建议 |
| 服务 | `src/service/` | 指标、持仓、行情、日历、ETF 映射、回测等业务编排 |
| 数据 | `src/database/` | ORM schema 与 repository |
| 模型 | `src/models/` | Pydantic 业务模型 |
| UI | `src/dashboard/` | Streamlit 五页仪表盘 |

## 每日流程

`src/runner/daily_runner.py` 是生产主链路：

```text
STEP 1: DataManager.sync_daily()
        补齐配置 ETF 到 T-1 交易日的 quote / nav / premium_rate
        同步宽基指数到 T-1 交易日的 market_index_quote

STEP 2: IndicatorService.calculate_and_save()
        计算技术指标和 LongTermOdds，写入 indicators.data

STEP 2B: MarketRegimeService.calculate_and_save()
         计算 T-1 市场热度，写入 market_regime

STEP 3: create_strategy(config).generate()
        从指标生成 BUY / SELL / HOLD，写入 signals

STEP 4: RiskController.check_position()
        对当前 positions 检查 90 日最大持有和 profile 止损

STEP 5: generate_advice()
        风控 > 高溢价门控 > 极端市场门控 > 加仓冷却 > 70/15/15 加仓预算 > 技术信号，
        生成 operation_advice，并写入建议预算、score、市场状态、止损 profile 和拦截原因
```

## 策略模型

当前生产策略：`multi_indicator_scoring`，并通过 `volatility_signal_profiles` 按 ETF `volatility_group` 选择 signal profile。

默认 v2.3 profile 用于 low_vol / unknown_vol：

```text
raw_score = 0.35*S_trend + 0.25*S_macd + 0.15*S_rsi + 0.25*S_bb
score = raw_score * vol_mult * adx_mult * 100
BUY  = score >= +50 且至少 2 个子信号为正
SELL = score <= -50 且至少 2 个子信号为负
HOLD = 其他情况
```

high_vol 使用 v2.5 `high_vol_balanced` profile：

| 子信号 | 权重 | 数据/处理 |
|---|---:|---|
| `S_trend` | 30% | MA20/MA60 趋势结构和价格相对短均线位置 |
| `S_macd` | 25% | DIF/DEA 动能方向，要求 MACD 不明显为负 |
| `S_rsi` | 15% | RSI 修复、过热衰减和弱势惩罚 |
| `S_bb` | 15% | 布林带位置，过度贴近上轨降权 |
| `S_volume` | 10% | 成交量相对 20 日均量确认 |
| `S_atr` | 5% | ATR 处于常态区间加分，极端波动降权 |

```text
BUY  = score >= 45 且趋势门槛通过、MACD 不明显为负、ADX>=18、至少 3 个正向确认
SELL = score <= -35 或跌破 MA20/MA60 且 MACD 转负的结构性破位
```

high_vol profile 依赖 `atr_pct`。若关键指标缺失，策略输出 HOLD，并在 `signal_meta.profile` 中保留 profile 信息用于排查。

## 当前生产基线

当前生产基线：`v2.5 limited = baseline-v2.4 + high_vol_balanced + high_vol quality_tier target budget`。

口径定义：

| 模块 | 生产处理 |
|---|---|
| 技术信号 | low_vol / unknown_vol 使用 v2.3 默认 profile；high_vol 使用 v2.5 `high_vol_balanced` |
| high_vol 目标预算 | score>=65 使用 100% 目标预算；55<=score<65 使用 80%；score<55 使用 60% |
| ATR 指标 | ATR(20) 写入 `indicators.data`，用于 high_vol 信号和 ATR profile 止损 |
| 长期赔率 | `EXPENSIVE` 不硬拦截；仅作为后续软门控/解释字段 |
| 溢价风险 | `odds_premium_blocked=True` 硬拦截建仓/加仓 |
| 市场热度 | 按 ETF `regime_group` 获取状态，仅 `HOT_FALLING / BEAR_TREND / PANIC` 硬拦截建仓/加仓 |
| A 股 ETF | 使用 A 股宽基综合 `market_regime` |
| 美股 ETF | 使用 NDX 单指数 regime |
| 港股 ETF | 使用恒生科技 HZ5017 单指数 regime |
| 市场状态 | `HOT_RISING / RECOVERY / NORMAL / UNKNOWN` 不硬拦截 |
| 建仓/加仓 | 单 ETF 目标预算内采用 70/15/15：70% 建仓，两次 15% 储备加仓 |
| 止损 | 按 ETF `stop_loss_profile` 执行；A 股高波动使用 `atr_2_5`，A 股低波动使用 `none`，跨境 ETF 暂用 `fixed_8` |
| 持有周期 | 最长 90 个自然日 |

启用或调整 signal profile 后必须重算 `signals`：

```text
uv run python main.py rebuild-signals --start 2024-06-01 --end 2026-06-03
```

基线结果（27 ETF，100,000 元，真实净值口径，交易成本 0.0005 + 滑点 0.0001）：

| 版本 | 年化收益 | 最大回撤 | Calmar | Sharpe | 胜率 | 利润因子 | 交易次数 |
|---|---:|---:|---:|---:|---:|---:|---:|
| baseline-v2.4, 2016-2026 | 11.45% | 26.34% | 0.4349 | 0.6794 | 39.64% | 1.6072 | 280 |
| v2.5 limited, 2016-2026 | 15.12% | 22.06% | 0.6854 | 0.8697 | 37.83% | 1.9753 | 423 |
| baseline-v2.4, 2024-2026 | 18.03% | 19.12% | 0.9430 | 0.8660 | 46.39% | 1.6752 | 97 |
| v2.5 limited, 2024-2026 | 38.83% | 17.57% | 2.2099 | 1.5425 | 40.76% | 3.0359 | 157 |

实验结论：high_vol 底层信号分离和质量分层目标预算已进入生产；静态总仓、高波暴露和持仓数上限没有优于该锚点，暂不采纳。后续策略更新以 `v2.5 limited` 为当前生产对照，`baseline-v2.4` 仅作为历史旧基线保留。

## 长期赔率门控

`LongTermOdds` 是 `v2.1A` 引入的长期赔率因子。它不产生交易信号。当前生产口径下，赔率状态用于解释和后续软门控实验；只有高溢价标记仍作为硬过滤。

价格基准：

```text
P_t = nav if nav exists else close
```

子因子：

| 字段 | 含义 |
|---|---|
| `odds_price_pct` | 当前价格在长期窗口中的分位 |
| `odds_drawdown` | 当前价格相对长期窗口高点的回撤 |
| `odds_zscore` | 当前价格相对长期均值的偏离 |
| `odds_hold_winrate_1y` | 历史任意时点持有 1 年的胜率 |
| `odds_hold_avg_return_1y` | 历史任意时点持有 1 年的平均收益 |
| `odds_risk_penalty` | 年化波动和最大回撤惩罚 |
| `odds_premium_blocked` | 溢价率超过阈值时的硬过滤标记 |

状态：

```text
CHEAP       odds_score >= +30
FAIR        -30 < odds_score < +30
EXPENSIVE   odds_score <= -30
INSUFFICIENT 历史数据不足
```

当前 advisor 门控：

| 原建议 | 条件 | 新建议 |
|---|---|---|
| 建仓 | 高溢价 `odds_premium_blocked=True` | 观望 |
| 加仓 | 高溢价 `odds_premium_blocked=True` | 继续持有 |
| 建仓/加仓 | `EXPENSIVE` | 不硬拦截，保留为解释/实验字段 |
| 卖出 | 任意赔率状态 | 不拦截 |

## 市场热度门控

`MarketRegimeService` 读取宽基指数日线行情，生成全市场状态快照。它不产生策略信号，只在 advisor 中对买入类建议做负向门控。

覆盖指数：

| 指数 | 代码 | 日常数据源 |
|---|---|---|
| 上证指数 | `000001` | BaoStock |
| 沪深300 | `000300` | BaoStock |
| 中证500 | `000905` | BaoStock |
| 中证1000 | `000852` | BaoStock |
| 创业板指 | `399006` | BaoStock |
| 科创50 | `000688` | AKShare，东方财富成交额尽力补充 |
| 纳指100 | `NDX` | AKShare 新浪美股指数 |
| 恒生科技 | `HZ5017` | Tushare `index_global(HKTECH)` |

历史数据：

```text
HistoryFetcher.get_index_history_from_tushare()
  -> index_daily
  -> market_index_quote

HistoryFetcher.get_global_index_history_from_tushare()
  -> index_global
  -> market_index_quote
```

Tushare 单位转换：

```text
volume: 手 -> 股，乘以 100
amount: 千元 -> 元，乘以 1000
index_global: 当前 HKTECH 只稳定提供 OHLC，volume/amount 可为空
```

分市场门控映射：

| ETF 分组 | regime 来源 |
|---|---|
| A 股 | A 股宽基综合 `market_regime` |
| 美股 | NDX 单指数 regime |
| 港股 | HZ5017 单指数 regime |

状态定义：

```text
COLD / NORMAL / HOT / HOT_RISING / HOT_FALLING / BEAR_TREND / PANIC / RECOVERY / UNKNOWN
```

第一版指标：

| 指标 | 用途 |
|---|---|
| 20/60 日涨跌幅 | 判断短中期涨跌速度 |
| close 相对 MA20/MA60 | 判断指数趋势结构 |
| RSI14 | 判断过热或极弱 |
| 成交额/成交量相对 20 日均值 | 判断市场活跃度 |
| 多指数一致性 | 判断全市场共振程度 |

当前 gate-lite advisor 门控：

| 市场状态 | 建仓 | 加仓 | 卖出 |
|---|---|---|---|
| `NORMAL` | 不拦截 | 不拦截 | 不拦截 |
| `HOT_RISING` | 不拦截 | 不拦截 | 不拦截 |
| `HOT_FALLING` | 降级为观望 | 降级为继续持有 | 不拦截 |
| `BEAR_TREND` | 降级为观望 | 降级为继续持有 | 不拦截 |
| `PANIC` | 降级为观望 | 降级为继续持有 | 不拦截 |
| `RECOVERY` | 不拦截 | 不拦截 | 不拦截 |
| `UNKNOWN` | 不拦截 | 不拦截 | 不拦截 |

## 加仓冷却与预算

`trade_records` 记录用户真实交易流水，advisor 用最近一次 `BUY / ADD` 日期控制加仓频率。默认冷却期由 `strategy.params.cooldown_days` 配置，当前模板为 5 天。

规则：

| 条件 | 处理 |
|---|---|
| 空仓 + BUY | 正常提示建仓 |
| 持仓 + BUY，冷却期外 | 正常提示加仓 |
| 持仓 + BUY，冷却期内 | 降级为继续持有，`signal_source=add_cooldown` |
| SELL 或风控信号 | 不受加仓冷却影响 |

70/15/15 加仓预算规则：

| 阶段 | 处理 |
|---|---|
| 建仓 | 使用单 ETF 目标预算的 70% |
| 第一次加仓 | 使用 15% 储备，要求浮盈且 score >= 60 |
| 第二次加仓 | 使用 15% 储备，要求浮盈且 score >= 70 |
| 加仓条件不满足 | 降级为继续持有，`signal_source=add_budget` |

## 当前数据状态

2026-06-20 已完成 v2.5 limited 生产基线固化：

| 数据域 | 状态 |
|---|---|
| ETF 映射 | 27 只 ETF 已写入 `settings.yaml` / `settings.yaml.example` 标准字段，并可通过 `etf_mapping` 表同步 |
| 恒生科技指数 | `HZ5017` 使用 Tushare `index_global(ts_code="HKTECH")`，已写入 1436 条，覆盖 2020-07-27 ~ 2026-06-03 |
| 港股门控 | `regime_group="港股"` 使用 HZ5017 单指数 regime |
| 生产策略 | low_vol 沿用 v2.3；high_vol 使用 `high_vol_balanced` 和质量分层目标预算 |
| 生产风控 | `max_holding_days(90)` + `profile_stop_loss` |
| 回归验证 | `uv run pytest -q` 通过 156 项 |

## 数据模型

当前 schema 包含 10 张业务表。

| 表 | 主键 | 职责 |
|---|---|---|
| `quote` | `(code, date)` | ETF 日线 OHLCV、NAV、溢价率 |
| `indicators` | `(code, date)` | 技术指标和长期赔率 JSONB 快照 |
| `signals` | `(code, date)` | 策略信号和 `signal_meta` |
| `positions` | `id` | 当前真实/手动维护持仓 |
| `trade_records` | `id` | 用户真实建仓、加仓、减仓、卖出流水 |
| `market_index_quote` | `(index_code, date)` | 宽基指数日线 OHLCV 和成交额 |
| `market_regime` | `date` | 市场热度状态快照 |
| `operation_advice` | `(code, date)` | 每日操作建议、成本和浮动盈亏 |
| `index_valuation` | `(index_code, date)` | 历史预留表；估值负向门控不进入当前优化路线 |
| `etf_mapping` | `symbol` | ETF 到市场、跟踪指数、行业、主题和 regime_group 的映射 |

核心字段：

```text
quote:
  code, date, open, high, low, close, volume, nav, premium_rate

indicators:
  code, date, data
  data: ma20, ma60, dif, dea, macd, bb_mid, bb_upper, bb_lower,
        bb_width, rsi, vol_ma20, vol_ratio, adx14, atr20, atr_pct, odds_*

signals:
  code, date, signal, strategy_version, signal_meta

positions:
  id, code, cost, shares, entry_date

trade_records:
  id, code, action, trade_date, price, shares, created_at
  action: TradeAction = BUY / ADD / REDUCE / SELL

market_index_quote:
  index_code, date, open, high, low, close, volume, amount

market_regime:
  date, state, score, data
  state: MarketState = COLD / NORMAL / HOT / HOT_RISING / HOT_FALLING /
                       BEAR_TREND / PANIC / RECOVERY / UNKNOWN

operation_advice:
  code, date, position_id, cost, pnl_pct, signal, advice, signal_source,
  target_position_ratio, target_budget_ratio, entry_add_step, score,
  market_state, stop_loss_profile, blocked_reason, advice_meta

etf_mapping:
  symbol, name, market, tracking_index, sector, theme, category, regime_group
```

核心业务枚举集中在 `src/models/enums.py`：

| 枚举 | 取值 | 用途 |
|---|---|---|
| `SignalType` | `BUY / SELL / HOLD` | 策略信号 |
| `TradeAction` | `BUY / ADD / REDUCE / SELL` | 用户真实交易流水 |
| `AdviceAction` | `建仓 / 加仓 / 观望 / 不操作 / 继续持有 / 卖出` | advisor 输出建议 |
| `SignalSource` | `trend / stop_loss / trailing_stop / max_holding / add_cooldown / add_budget / market_regime` | 建议来源 |
| `MarketState` | `COLD / NORMAL / HOT / HOT_RISING / HOT_FALLING / BEAR_TREND / PANIC / RECOVERY / UNKNOWN` | 市场热度状态 |

## 数据源

| 来源 | 模块 | 作用 |
|---|---|---|
| BaoStock | `DailyFetcher` | 日常 OHLCV 增量，自动前复权 |
| BaoStock | `MarketIndexFetcher` | 上证、沪深300、中证500、中证1000、创业板指日常指数行情 |
| AKShare/EastMoney | `DailyFetcher` | NAV 与溢价率 |
| AKShare/EastMoney | `MarketIndexFetcher` | 科创50日常行情与成交额补充 |
| Tushare | `HistoryFetcher` | ETF 历史 OHLCV、宽基指数历史 OHLCV |
| Tushare | `HistoryFetcher.get_global_index_history_from_tushare` | 恒生科技 HZ5017/HKTECH 全球指数历史 OHLC |
| exchange_calendars | `TradingCalendarService` | 上交所交易日历 |

Tushare 前复权公式：

```text
adjusted_price = raw_price * current_adj_factor / latest_adj_factor
```

Tushare 不提供 NAV，因此历史回填不会覆盖已有带 NAV 的 `quote` 记录。

初始化入口：

```text
main.py init
  全量初始化：建表 -> 同步 etf_mapping -> ETF 行情 -> 指数行情 -> market_regime -> ETF 指标 -> 信号

main.py init-market
  同步 etf_mapping，并初始化 market_index_quote 和 market_regime，适合 ETF 数据已完成的环境

main.py rebuild-signals
  不改 quote / indicators，按指定区间删除并重算 signals，刷新最新 operation_advice

main.py sync-etf-mapping
  只把 settings.yaml 中的 ETF 映射同步到 etf_mapping 表

ablation.py
  消融实验入口，承接 entry-add-budget、stop-loss、reentry 等本地实验矩阵
```

## 扩展点

- 新指标：新增 `BaseIndicator`，注册到 `IndicatorService` 调用方，输出列自然落入 `indicators.data`。
- 新策略：新增 `BaseStrategy`，在 `factory.py` 和 `settings_reader.py` 注册，参数写入配置。
- 新风控：新增 `BaseRiskRule`，通过配置加入规则链。
- 新展示：Dashboard 从 service/repository 取数据，不在 UI 层写策略判断。

## 已知边界

- 舆情事件、行业资金流和基本面估值负向门控已从当前优化路线移除，原因是实施成本高且预期收益不确定。
- `index_valuation` 是历史预留表，不进入当前生产链路。
- `settings.yaml.example` 是模板，实际 ETF 列表和密钥在本地配置中维护。
- 回测结果依赖历史数据完整性，特别是 Tushare 回填覆盖范围和 NAV 缺失情况。
- 当前 `backtest-odds` 的组合最大回撤为多 ETF 盈亏累加口径，不是真实资金账户净值口径；适合版本相对比较，不适合直接作为账户回撤结论。
- Dashboard 建仓/加仓/减仓/清仓已下沉到 `PositionService` 原子交易方法，`positions` 与 `trade_records` 同一 DB session 提交。
