# 策略优化建议

本文档基于对项目架构（Archi.md）和推进计划（PLAN.md）的深度分析，以资深量化交易员视角提出策略优化建议。

当前策略核心：`multi_indicator_scoring`（趋势/MACD/RSI/布林带）+ 长期赔率门控 + 市场热度门控 + 加仓冷却 + 风控止损止盈。

当前回测表现（26 只 ETF，v2.2）：胜率 31.2%，累计盈亏 +46.4%，但信号质量仍有提升空间。

---

## P0：信号层优化（直接影响胜率和回撤）

### 建议 1：趋势强度过滤 — 加入 ADX

**建议原因**

当前 `S_trend` 只看 MA20/MA60 排列和价格相对位置，无法区分"强趋势"和"横盘震荡中的均线纠缠"。震荡市中均线频繁金叉死叉，产生大量假信号，是胜率偏低的主要原因之一。

ADX（Average Directional Index）是经典的趋势强度指标，能有效区分趋势市和震荡市：
- ADX > 25：趋势明确，均线信号可信度高
- ADX < 20：无趋势/震荡，均线信号噪音大
- ADX 20-25：弱趋势，信号可信度中等

**建议实施方案**

1. 在 `src/indicators/` 新增 `ADXIndicator`，实现 `BaseIndicator.calculate(df) -> DataFrame`
2. 计算 ADX、+DI、-DI，输出列：`adx`, `plus_di`, `minus_di`
3. 修改 `multi_indicator_scoring` 策略中的 `S_trend` 计算逻辑：
   ```python
   if adx > 25:
       trend_weight = 0.35  # 强趋势，正常权重
   elif adx > 20:
       trend_weight = 0.25  # 弱趋势，降权
   else:
       trend_weight = 0.15  # 震荡市，大幅降权
   ```
4. 在 `IndicatorService` 注册 ADX 计算
5. 补充单元测试：验证 ADX 在趋势市和震荡市的区分效果
6. 回测对比：在 588000、159992 上对比开启/关闭 ADX 过滤的效果

**预期收益**：震荡市假信号减少 30-40%，最大回撤改善 3-5pct。

---

### 建议 2：布林带策略修正 — 区分突破与回归

**建议原因**

当前 `S_bb` 计算价格在布林带中的位置，逻辑是"接近上轨给高分，接近下轨给低分"。这个逻辑在趋势市中是错误的：

- 强趋势中价格会沿上轨运行（布林带通道上升），此时应持盈而非卖出
- 只有在震荡市中，触及上轨才是回归信号，触及下轨才是反弹信号

当前策略没有区分这两种场景，导致趋势市中过早卖出、震荡市中追高。

**建议实施方案**

1. 复用建议 1 的 ADX 指标判断市场状态
2. 修改 `S_bb` 计算逻辑：
   ```python
   bb_position = (close - bb_lower) / (bb_upper - bb_lower)  # 0-1 之间

   if adx > 25:  # 趋势市
       # 价格在上轨附近 → 趋势延续，给正分
       # 价格跌破中轨 → 趋势破位，给负分
       if bb_position > 0.8:
           s_bb = +0.6  # 趋势延续
       elif bb_position < 0.5:
           s_bb = -0.4  # 趋势破位风险
       else:
           s_bb = 0
   else:  # 震荡市
       # 回归逻辑：上轨附近给低分，下轨附近给高分
       s_bb = (0.5 - bb_position) * 1.2  # 反转为回归信号
   ```
3. 补充单元测试：分别验证趋势市和震荡市的 S_bb 输出
4. 回测对比：重点观察趋势市中是否减少了过早卖出

**预期收益**：趋势市中避免过早卖出，提升盈利交易的持仓周期。

---

### 建议 3：RSI 优化 — 动态阈值

**建议原因**

RSI 固定阈值（通常 30/70）在不同市场环境下表现差异大：
- 牛市中 RSI 50-70 是常态，固定 70 阈值会频繁触发"超买"
- 熊市中 RSI 30-50 是常态，固定 30 阈值会频繁触发"超卖"

用 RSI 相对自身历史分位来判断，能自适应市场环境。

**建议实施方案**

1. 在 `RSIIndicator` 中新增 RSI 分位计算：
   ```python
   rsi_60d_pct = rsi.rolling(60).apply(lambda x: (x.iloc[-1] < x).sum() / len(x))
   ```
2. 修改 `S_rsi` 计算逻辑：
   ```python
   # rsi_pct: 0-1，表示 RSI 在近 60 日的相对位置
   if rsi_pct > 0.85:  # RSI 处于近 60 日高位
       s_rsi = -0.3  # 超买警告
   elif rsi_pct < 0.15:  # RSI 处于近 60 日低位
       s_rsi = +0.3  # 超卖反弹
   else:
       s_rsi = (0.5 - rsi_pct) * 0.5  # 中性区域
   ```
3. 回测对比：观察是否减少了牛市中的假超卖信号和熊市中的假超买信号

**预期收益**：RSI 信号在不同市场环境下的稳定性提升。

---

## P1：卖出机制优化（直接影响盈亏比）

### 建议 4：波动率自适应止损

**建议原因**

当前固定 8% 止损没有考虑不同 ETF 的波动特性：
- 高波动品种（如科创 50、半导体 ETF）日均波动 2-3%，8% 止损频繁触发
- 低波动品种（如国债 ETF、红利 ETF）日均波动 0.5%，8% 止损又太宽

用 ATR（Average True Range）动态止损，让止损线自适应波动率。

**建议实施方案**

1. 复用现有 ATR 计算或在 `indicators` 中新增 ATR20
2. 修改风控止损逻辑：
   ```python
   # 基础止损
   base_stop = 0.08
   # 波动率自适应止损：至少 2.5 倍 ATR
   atr_stop = (atr20 / current_price) * 2.5
   # 取较大值，确保止损不会太紧
   stop_loss_pct = max(base_stop, atr_stop)
   ```
3. 在 `settings.yaml.example` 中新增参数：
   ```yaml
   risk:
     base_stop_loss: 0.08
     atr_multiplier: 2.5
     min_stop_loss: 0.05  # 最低止损线
     max_stop_loss: 0.15  # 最高止损线
   ```
4. 回测对比：重点观察高波动 ETF（588000、159992）的止损次数和假止损率

**预期收益**：高波动 ETF 假止损减少，低波动 ETF 亏损控制更紧。

---

### 建议 5：阶梯式移动止盈

**建议原因**

当前"10% 浮盈后 3% 回撤止盈"是单一阈值，没有根据浮盈幅度动态调整回撤容忍度：

- 浮盈 5-10% 时，3% 回撤止损是合理的
- 浮盈 20% 时，3% 回撤止损太紧，容易在正常回调中被洗出
- 浮盈 30%+ 时，应该给更大的回撤空间，让利润奔跑

阶梯式止盈能保护已有浮盈，同时让强势行情中的利润充分释放。

**建议实施方案**

1. 修改风控止盈逻辑：
   ```python
   if unrealized_pnl_pct >= 0.30:
       trailing_pct = 0.08  # 浮盈 30%+，回撤 8% 止盈（锁定 22%+）
   elif unrealized_pnl_pct >= 0.20:
       trailing_pct = 0.06  # 浮盈 20-30%，回撤 6% 止盈（锁定 14%+）
   elif unrealized_pnl_pct >= 0.10:
       trailing_pct = 0.04  # 浮盈 10-20%，回撤 4% 止盈（锁定 6%+）
   else:
       trailing_pct = 0.03  # 浮盈 5-10%，回撤 3% 止盈
   ```
2. 在 `settings.yaml.example` 中新增参数：
   ```yaml
   risk:
     trailing_stop:
       - min_pnl: 0.05
         max_pnl: 0.10
         drawdown: 0.03
       - min_pnl: 0.10
         max_pnl: 0.20
         drawdown: 0.04
       - min_pnl: 0.20
         max_pnl: 0.30
         drawdown: 0.06
       - min_pnl: 0.30
         max_pnl: 999
         drawdown: 0.08
   ```
3. 回测对比：观察盈利交易的平均持仓周期和平均收益是否提升

**预期收益**：让利润奔跑，盈利交易的平均收益提升 2-5pct。

---

## P2：仓位管理（影响组合风险）

### 建议 6：信号强度分级仓位

**建议原因**

当前建仓/加仓是二元决策（买或不买），没有根据信号强度调整仓位大小。这意味着：
- 强信号（score 80+）和中等信号（score 55）获得相同的仓位
- 无法在高确信度时重仓、低确信度时轻仓

分级仓位能提升整体盈亏比：强信号重仓吃大肉，弱信号轻仓试水。

**建议实施方案**

1. 在 advisor 输出中新增 `position_pct` 字段：
   ```python
   if score >= 70:
       position_pct = 1.0  # 强信号，建议建仓 100% 目标仓位
   elif score >= 50:
       position_pct = 0.5  # 中等信号，建议建仓 50% 目标仓位
   else:
       position_pct = 0  # 不建仓
   ```
2. Dashboard 展示建议仓位比例，由用户自行决定执行
3. 回测对比：观察不同仓位策略下的夏普比率和最大回撤

**预期收益**：提升夏普比率，强信号交易的收益贡献更显著。

---

### 建议 7：组合层面风控

**建议原因**

当前风控只看单 ETF，没有组合层面的风险控制：
- 多只 ETF 同时下跌时，组合回撤可能远超单只 ETF 的止损线
- 同一行业/主题的 ETF 高度相关，集中持仓会放大风险
- 缺乏整体仓位上限控制

组合层面风控能在系统性风险来临时保护整体资金。

**建议实施方案**

1. 新增组合风控检查：
   ```python
   # 组合浮亏检查
   total_unrealized_pnl = sum(position.pnl_pct * position.weight for position in positions)
   if total_unrealized_pnl < -0.15:
       # 组合浮亏超 15%，暂停所有新建仓
       block_new_entry = True

   # 行业集中度检查
   sector_exposure = calculate_sector_exposure(positions)
   if max(sector_exposure.values()) > 0.4:
       # 单行业暴露超 40%，暂停该行业新买入
       block_sector = max(sector_exposure, key=sector_exposure.get)
   ```
2. 在 `etf_mapping` 表中补充行业/主题映射
3. Dashboard 新增组合风险监控面板

**预期收益**：系统性风险下的回撤控制，避免单一行业黑天鹅事件。

---

## P3：市场环境优化

### 建议 8：市场热度指标增强

**建议原因**

当前市场热度只用涨跌幅、均线、RSI、成交量，缺少以下关键维度：
- **波动率指标**：VIX 类指标能反映市场恐慌程度，是市场底部/顶部的重要信号
- **市场宽度**：涨跌比能判断市场是普涨还是少数股票带动的虚假繁荣
- **新高新低比**：创 20 日新高 vs 新低的数量，反映市场动能

补充这些指标能让市场热度判断更立体、更准确。

**建议实施方案**

1. 新增波动率指标：
   ```python
   # 用宽基指数的 20 日历史波动率
   hist_vol = returns.rolling(20).std() * np.sqrt(252)
   vol_zscore = (hist_vol - hist_vol.rolling(60).mean()) / hist_vol.rolling(60).std()
   ```
2. 新增市场宽度指标：
   ```python
   # 计算当日上涨/下跌 ETF 数量
   up_count = (etf_returns > 0).sum()
   down_count = (etf_returns < 0).sum()
   advance_decline_ratio = up_count / (up_count + down_count)
   ```
3. 在 `market_regime` 的 `data` 字段中补充这些指标
4. 修改市场热度评分逻辑，给新指标适当权重

**预期收益**：市场状态判断更准确，减少 HOT/COLD 误判。

---

### 建议 9：市场状态细分

**建议原因**

当前 HOT/COLD 太粗糙，没有区分"过热但仍在上涨"和"过热且开始回落"：
- `HOT` + 仍在上涨 → 可能是泡沫中期，谨慎但不必完全禁止
- `HOT` + 开始回落 → 泡沫破裂风险高，必须禁止买入
- `COLD` + 企稳 → 可能是底部，可考虑左侧布局
- `COLD` + 继续下跌 → 接飞刀风险高，必须禁止买入

细分市场状态能让门控更精准。

**建议实施方案**

1. 修改 `MarketState` 枚举：
   ```python
   class MarketState(Enum):
       HOT_RISING = "hot_rising"      # 过热但仍在上涨
       HOT_FALLING = "hot_falling"    # 过热且开始回落
       NORMAL = "normal"              # 正常
       COLD_BOTTOM = "cold_bottom"    # 超卖且企稳
       COLD_FALLING = "cold_falling"  # 超卖且仍在下跌
       UNKNOWN = "unknown"
   ```
2. 在热度计算中新增趋势判断：
   ```python
   # 判断近期趋势方向
   recent_return = (index_close.iloc[-1] / index_close.iloc[-5]) - 1
   if state == "HOT" and recent_return > 0:
       state = "HOT_RISING"
   elif state == "HOT" and recent_return < 0:
       state = "HOT_FALLING"
   ```
3. 修改 advisor 门控规则：
   ```python
   if state == "HOT_FALLING":
       block_buy = True  # 严格禁止买入
   elif state == "HOT_RISING":
       downgrade_buy = True  # 降级为观望
   elif state == "COLD_FALLING":
       block_buy = True  # 严格禁止买入
   elif state == "COLD_BOTTOM":
       # 可考虑左侧布局，但需要额外确认
       pass
   ```

**预期收益**：减少 HOT 状态下的误拦截，同时在真正危险的 HOT_FALLING 状态下严格防守。

---

## P4：回测框架优化

### 建议 10：真实资金口径回撤

**建议原因**

当前最大回撤是多 ETF 盈亏累加口径，不是真实账户净值口径：
- 无法准确衡量组合风险
- 无法与基金、指数等标准化产品对比
- 无法用于计算夏普比率、卡玛比率等风险调整收益指标

实现真实资金口径回撤是量化回测的基本要求。

**建议实施方案**

1. 新增组合净值计算：
   ```python
   # 每日账户净值
   daily_nav = initial_capital
   for position in positions:
       daily_nav += position.shares * current_price - position.cost

   # 最大回撤
   peak = max(peak, daily_nav)
   drawdown = (peak - daily_nav) / peak
   max_drawdown = max(max_drawdown, drawdown)
   ```
2. 修改回测输出：
   ```python
   return {
       "total_return": (final_nav - initial_capital) / initial_capital,
       "max_drawdown": max_drawdown,
       "sharpe_ratio": calculate_sharpe(returns),
       "calmar_ratio": total_return / max_drawdown,
   }
   ```
3. Dashboard 新增净值曲线展示

**预期收益**：准确衡量组合风险，支持与标准化产品对比。

---

## 实施优先级总览

| 优先级 | 建议 | 开发成本 | 预期收益 | 依赖关系 |
|---|---|---|---|---|
| **立即做** | 1. ADX 趋势强度过滤 | 低 | 中高 | 无 |
| **立即做** | 4. 波动率自适应止损 | 低 | 中 | 无 |
| **尽快做** | 2. 布林带策略修正 | 中 | 高 | 依赖建议 1 |
| **尽快做** | 5. 阶梯式移动止盈 | 低 | 中 | 无 |
| **尽快做** | 10. 真实资金口径回撤 | 中 | 高 | 无 |
| **计划做** | 3. RSI 动态阈值 | 低 | 中 | 无 |
| **计划做** | 6. 信号强度分级仓位 | 中 | 中 | 无 |
| **计划做** | 7. 组合层面风控 | 中 | 高 | 需要 etf_mapping |
| **后续做** | 8. 市场热度指标增强 | 高 | 中 | 无 |
| **后续做** | 9. 市场状态细分 | 中 | 中 | 无 |

---

## 关键约束提醒

1. **避免未来函数**：所有新增指标必须用历史数据计算，不能用当日数据判断当日信号
2. **保持可回测**：每个优化项必须能独立开关，便于做消融实验验证边际贡献
3. **参数少即是多**：当前已有 4 个子信号 + 赔率 + 市场热度 + 冷却，新增因子要谨慎，避免过拟合
4. **先验证再上线**：每个优化项先在 3-5 只代表性 ETF 上回测，确认有效后再全量推广
5. **保持架构分层**：指标计算在 `indicators`，信号生成在 `strategy`，风控在 `risk`，不要破坏现有分层

---

## 附录：代表性 ETF 选择

建议优先在以下 ETF 上验证优化效果：

| ETF | 代码 | 特性 | 验证目的 |
|---|---|---|---|
| 科创 50 | 588000 | 高波动、趋势明显 | 验证趋势市优化效果 |
| 医药 ETF | 512010 | 中波动、震荡较多 | 验证震荡市优化效果 |
| 红利 ETF | 510880 | 低波动、稳定 | 验证低波动品种优化效果 |
| 半导体 | 512480 | 高波动、行业集中 | 验证行业风控效果 |
| 沪深 300 | 510300 | 宽基、代表性强 | 验证整体策略效果 |
