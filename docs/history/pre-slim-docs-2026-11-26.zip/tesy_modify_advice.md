# 回测架构梳理与修改建议

本文是一次代码架构梳理的产出,目标是确认**当前回测实验架构能否证明策略有效性**,并列出按性价比排序的修改建议。结论基于对生产主链路、回测主引擎、各实验脚本的逐行核读。

## 一句话结论

回测引擎的核心方法论**扎实可信**(真实账户净值口径 + T+1 无未来函数撮合 + 与生产共用 `generate_advice`),足以支撑策略有效性论证。但工程整洁度上有若干硬伤(死代码、误导属性、两套口径并存、实验结论不可追溯),它们不会推翻结论,却会让人质疑结论,也违背代码洁癖。

---

## 一、生产主链路架构(分层清晰,值得肯定)

```text
fetcher → quote表 → indicators → strategy → risk → advisor → operation_advice表 → dashboard
 STEP1     (DB)      STEP2        STEP3       STEP4    STEP5        (DB)            只读渲染
```

编排者是 `src/runner/daily_runner.py` 的 `run_daily()`。关键事实:

- **层间几乎全靠数据库表解耦**,不直接传对象。唯一在内存中跨步传递的是 STEP4→STEP5 的 `risk_signals` dict。每层可独立测试、独立回放。
- **数据截止日是 T-1**(`get_previous_trading_day`),生产链路本身就避免使用当天未收盘数据。
- 新因子(如 v2.1A 赔率)写入 `indicators.data` JSONB,不 ALTER TABLE,符合 Agent.md 规范。

各层职责:fetcher(`DataManager`/`DailyFetcher`)采集写 `quote`;`IndicatorService` 注册 8 个计算器写 `indicators.data`;`MultiIndicatorScoring` 产 BUY/SELL/HOLD 写 `signals`;`RiskController` 装配规则链返回首个触发结果;`generate_advice` 纯函数按优先级门控产 `operation_advice`。

---

## 二、回测引擎口径审计(核心)

### ✅ 做对了的关键点(决定回测可信度)

1. **真实账户净值口径**(`portfolio_backtest.py` `PortfolioState`):`cash + 持仓×当日收盘价 = total_equity`,共享现金池、单标的仓位上限、佣金 + 滑点全建模。不是会统计放大的"多 ETF 盈亏累加"假口径。

2. **T+1 撮合,无未来函数**(`portfolio_backtest.py:586`)——回测可信度的命根子:
   - T 日收盘后用 T 日数据生成建议 → 缓存进 `pending_advices[T+1]`
   - 推进到 T+1 日,用 **T+1 当日实际价格**成交(`:548-563`)
   - 信号/风控判断全部基于当日及历史,执行落在 `get_next_trading_day`
   - **决策与成交严格分离,无"今天信号按今天收盘成交"的穿越。**

3. **回测复用生产 `generate_advice`**(`:682`):回测和实盘走同一个 advisor 函数,门控逻辑(赔率/市场/冷却)不会两套漂移。符合 Agent.md 的生产一致性要求。

4. **绩效指标口径正确**(`portfolio_metrics.py`):最大回撤用净值峰值口径、Calmar=年化/回撤、Sharpe 用日收益序列年化。配对平仓用**现金流**(含成本)算盈亏,比用价格更真实。

### 引擎口径全景:实际是两套,不是三套

| | 主引擎 `PortfolioBacktest` | `OddsGateBacktest`(独立) |
|---|---|---|
| 复用主引擎 | — | **否**,自写 `_simulate_version` 循环 |
| 撮合时序 | T+1,缓存到 pending、推进到当天成交 | T+1,但前瞻取次日收盘价塞事件流 |
| 净值/盈亏口径 | 真实账户净值(cash+市值) | **多 ETF 百分比盈亏累加**(`_VIRTUAL_SHARES=1000` 等权,无现金池/仓位上限) |
| 风控 | 完整 `_check_risk`(止损/ATR/trailing/最大持有) | **无**(传 `current_prices={}`、`risk_signals={}`) |
| 用 `generate_advice` | 是 | 是(调 3 次做门控拦截统计) |
| 交易成本 | 佣金 0.0005 + 滑点 0.0001,逐笔扣 | 写死 0.00005,按交易数×2 事后从百分比里减 |
| 入口 | ablation.py / ds_backtest 全部复用 | `main.py backtest-odds` |

**关键结论:**

- **`src/ds_backtest/` 的两个 reentry 脚本与主引擎是同一套引擎**(直接 new `PortfolioBacktest`,或经 `ablation_report.run_ablation_backtest` 间接),结果**可与主引擎互相比较**。它们只是"换实验配置 + 渲染报告"的 driver。
- **`odds_gate_backtest.py` 是一套独立的、口径不同的引擎**,其年化/回撤/累计盈亏**不能与主引擎或 reentry 实验的数字直接并列**。它只适合在自身口径内做"赔率门控 vs 无门控"的相对增量对比。
- "三套引擎"的表象来自 `odds_gate` 自己跑了 v2.0/v2.1A/v2.2 三个变体,但那是同一套 `_simulate_version` 内核。

---

## 三、必须修正的问题

### 问题1 — `market_value` 属性用成本而非市值,有误导风险
`portfolio_backtest.py:79-80`:
```python
def market_value(self) -> float:
    return sum(p.cost for p in self.positions.values())  # ← 用的是成本!
```
真正的净值曲线靠 `market_value_at(prices)`(当日价)算,主循环记净值用的是对的(`:579`)。但这个 `market_value`/`total_equity` 属性被 **dashboard 的 pnl 页直接读取**(`pnl.py:131,165-167`),导致 dashboard 展示的"最终权益/市值"是**成本口径**,与真实净值不一致。
**修法**:统一为市值口径,或删属性强制走 `_at(prices)`,让 dashboard 不再展示成本口径。

### 问题2 — `load_data` 契约腐烂(死代码 + 文档撒谎)
`portfolio_backtest.py:160-252`:docstring 声明返回 5 元组含 `signals_by_version`,实际 `return` 只返回 4 个值;函数内辛苦算出的 `signals_df_by_version` 既未返回也未使用(真正的信号加载在 `_load_unified_signals`,`:287`)。
**修法**:删掉未使用的 `signals_df_by_version` 计算分支,修正 docstring 与实际返回一致。

### 问题3 — 两套口径并存,需明确边界
`OddsGateBacktest` 与主引擎口径不可比,但它仍是 `main.py` 的一级子命令,容易让人误把它的数字与主引擎数字并列。
**修法**:在 `odds_gate_backtest.py` 顶部和 `main.py` 帮助文本明确标注"简化口径,仅用于门控相对对比,数字不可与组合回测并列";长期考虑用主引擎重写门控对比,或将其降级为归档实验。

### 问题4 — 实验脚本缺统一台账,结论不可追溯
`src/backtest/` 下有 19 个 `*_report.py`(`high_vol_quality_*`、`volatility_*`、`relative_strength_*` 等),`src/ds_backtest/` 另有 reentry 实验。这些是探索性实验,但**哪些结论被采纳进生产、哪些被否决(如 README 提到相对强弱不采纳),从目录看不出来**。证明有效性需要"实验→结论→是否进生产"的可追溯链路。
**修法**:在 `docs/` 建实验台账表,记录每个实验脚本 → 核心结论 → 是否进生产 → 对应配置项。

---

## 四、有效性总体判断

| 维度 | 状态 |
|---|---|
| 净值口径真实性 | ✅ 真实账户口径,可信 |
| 无未来函数 | ✅ T+1 撮合严格,决策/成交分离 |
| 生产-回测一致性 | ✅ 共用 `generate_advice` |
| 指标计算正确性 | ✅ 回撤/Calmar/Sharpe 口径正确 |
| 单一引擎权威性 | ⚠️ 两套口径并存,odds_gate 不可与主引擎比 |
| 实验结论可追溯 | ⚠️ 19+脚本散落,采纳与否不可见 |
| 死代码/契约腐烂 | ⚠️ `load_data` 撒谎,market_value 误导 |

---

## 五、建议的梳理动作(按性价比排序)

1. **建实验台账**(问题4):产出"实验→结论→是否进生产"表,直接服务有效性可追溯性。改动为纯文档,零代码风险。
2. **清死代码**(问题2):修 `load_data` 返回契约,删未使用的 `signals_df_by_version`。
3. **修 `market_value` 属性**(问题1):统一市值口径,纠正 dashboard 展示。
4. **标注口径边界**(问题3):给 `OddsGateBacktest` 加显式口径警告,避免数字误并列。

每一步均可独立验证、互不阻塞。建议先做 1、2(零风险),再做 3、4。
